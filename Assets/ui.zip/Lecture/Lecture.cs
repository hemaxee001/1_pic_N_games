using System.Collections.Generic;
using System.Data;
using UnityEngine;
using UnityEngine.UI;

public class Lecture : MonoBehaviour
{

    public GameObject screen1, screen2;

    public void openScreen()
    {
        screen1.SetActive(false);
        screen2.SetActive(true);
    }

}
